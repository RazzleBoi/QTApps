#pragma once
#include <qwidget.h>
#include <qlistwidget.h>
#include <qlineedit.h>
#include "service.h"
#include "domain.h"
#include <qpushbutton.h>
#include <qlayout.h>
#include <vector>

using namespace std;
class GUI :
	public QWidget
{
private:
	Service service;
	//graphical
	QListWidget* tapeListWidget, *fieldAgentsWidget;
	QLineEdit* titleLineEdit, * filmedLocationLineEdit, * dateLineEdit, * accessCountLineEdit, * footagePreviewLineEdit;
	QPushButton* addButton, * deleteButton, * updateButton, * saveButton, * filterButton, * nextButton;

public:
	GUI();
	void initGUI();
	void populateRepoList();
	void populateMyList();
	void connectSignalsAndSlots();

	int getSelectedIndex() const;
	void addTape();
	void deleteTape();
	void saveTape();
	void filterTape();
	void updateTape();
	void nextTape();
};

