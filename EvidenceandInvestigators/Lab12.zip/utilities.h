#pragma once
#include <string>
#include <stdlib.h>
#include <ctype.h>
#include <iostream>
#include "domain.h"
using namespace std;
int strToInt(string inputString);

date stringToDate(string dateString);

