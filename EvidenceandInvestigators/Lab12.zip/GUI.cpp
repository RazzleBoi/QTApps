#include <qwindow.h>
#include <qmainwindow.h>
#include "GUI.h"
#include <qformlayout.h>
#include <qgridlayout.h>
#include <qlabel.h>
#include <qmessagebox.h>
#include "utilities.h"
GUI::GUI()
{
	service.configureRepo();
	initGUI();
	populateRepoList();
	populateMyList();
	connectSignalsAndSlots();
}
void GUI::initGUI()
{
	tapeListWidget = new QListWidget{};
	fieldAgentsWidget = new QListWidget{};
	titleLineEdit = new QLineEdit{};
	filmedLocationLineEdit = new QLineEdit{};
	dateLineEdit = new QLineEdit{};
	accessCountLineEdit = new QLineEdit{};
	footagePreviewLineEdit = new QLineEdit{};
	addButton = new QPushButton{"Add"};
	deleteButton = new QPushButton{"Delete"};
	updateButton = new QPushButton{"Update"};
	saveButton = new QPushButton{"Save"};
	nextButton = new QPushButton{"Next"};
	filterButton = new QPushButton{"Filter"};
	
	QVBoxLayout *leftLayout = new QVBoxLayout{ };
	QLabel* repoList = new QLabel("List of tapes");
	leftLayout->addWidget(repoList);
	leftLayout->addWidget(this->tapeListWidget);

	QFormLayout *tapeAttributes = new QFormLayout{};
	tapeAttributes->addRow("Title", this->titleLineEdit);
	tapeAttributes->addRow("Filmed Location", this->filmedLocationLineEdit);
	tapeAttributes->addRow("Date", this->dateLineEdit);
	tapeAttributes->addRow("Access count", this->accessCountLineEdit);
	tapeAttributes->addRow("Footage Preview", this->footagePreviewLineEdit);
	leftLayout->addLayout(tapeAttributes);

	QGridLayout* buttonsLayout = new QGridLayout{};
	buttonsLayout->addWidget(addButton, 0, 0);
	buttonsLayout->addWidget(updateButton, 0, 1);
	buttonsLayout->addWidget(deleteButton, 0, 2);
	buttonsLayout->addWidget(saveButton, 1, 0);
	buttonsLayout->addWidget(nextButton, 1, 1);
	buttonsLayout->addWidget(filterButton, 1, 2);
	leftLayout->addLayout(buttonsLayout);

	QVBoxLayout* rightLayout = new QVBoxLayout{ };
	QLabel* myListLabel = new QLabel("Field Agents list");
	rightLayout->addWidget(myListLabel);
	rightLayout->addWidget(this->fieldAgentsWidget);

	QHBoxLayout* mainLayout = new QHBoxLayout{ this };
	mainLayout->addLayout(leftLayout);
	mainLayout->addLayout(rightLayout);


}

void GUI::populateRepoList()
{
	this->tapeListWidget->clear();
	vector<Tape> tapesFromRepo = service.getListOfAllTapes();
	for (Tape currentTape : tapesFromRepo) {
		this->tapeListWidget->addItem(QString::fromStdString(currentTape.toString()));
	}
}

void GUI::populateMyList()
{
	this->fieldAgentsWidget->clear();
	vector<Tape> tapesFromRepo = service.getFieldAgentsList();
	for (Tape currentTape : tapesFromRepo) {
		this->fieldAgentsWidget->addItem(QString::fromStdString(currentTape.toString()));
	}
}

void GUI::connectSignalsAndSlots()
{
	
	QObject::connect(this->tapeListWidget, &QListWidget::itemSelectionChanged, [this]() {
		int selectedIndex = this->getSelectedIndex();
		if (selectedIndex < 0)
			return;
		Tape selectedTape = service.getListOfAllTapes()[selectedIndex];
		this->titleLineEdit->setText(QString::fromStdString(selectedTape.getTitle()));
		this->filmedLocationLineEdit->setText(QString::fromStdString(selectedTape.getFilmedAt()));
		this->dateLineEdit->setText(QString::fromStdString(selectedTape.getDate()));
		this->accessCountLineEdit->setText(QString::fromStdString(to_string(selectedTape.getAccessCount())));
		this->footagePreviewLineEdit->setText(QString::fromStdString(selectedTape.getFootagePreview()));
		});
	QObject::connect(this->addButton, &QPushButton::clicked,this,  &GUI::addTape);
	QObject::connect(this->updateButton, &QPushButton::clicked, this, &GUI::updateTape);
	QObject::connect(this->deleteButton, &QPushButton::clicked,this,  &GUI::deleteTape);
	QObject::connect(this->saveButton, &QPushButton::clicked,this,  &GUI::saveTape);
	QObject::connect(this->filterButton, &QPushButton::clicked,this,  &GUI::filterTape);
	QObject::connect(this->nextButton, &QPushButton::clicked,this,  &GUI::nextTape);
}


int GUI::getSelectedIndex() const
{
	QModelIndexList selectedIndexes = this->tapeListWidget->selectionModel()->selectedIndexes();
	if (selectedIndexes.size() == 0) {
		this->titleLineEdit->clear();
		this->filmedLocationLineEdit->clear();
		this->dateLineEdit->clear();
		this->accessCountLineEdit->clear();
		this->footagePreviewLineEdit->clear();
		return -1;
	}
	int selectedIndex = selectedIndexes.at(0).row();
	return selectedIndex;
}

void GUI::addTape()
{
	string title = this->titleLineEdit->text().toStdString();
	string filmedLocation = this->filmedLocationLineEdit->text().toStdString();
	date adate = stringToDate(this->dateLineEdit->text().toStdString());
	int accessCount = this->accessCountLineEdit->text().toInt();
	string footagePreview = this->footagePreviewLineEdit->text().toStdString();
	Tape tapeToAdd(title, filmedLocation, adate.day, adate.month, adate.year, accessCount, footagePreview);
	try {
		service.addTape(tapeToAdd);
	}
	catch (repoError re) {
		QMessageBox::critical(this, "Repo Error", re.what());
		return;
	}
	catch (validatorError ve) {
		QMessageBox::critical(this, "Validator Error", ve.what());
		return;
	}
	populateRepoList();
}

void GUI::deleteTape()
{
	string title = this->titleLineEdit->text().toStdString();
	if (title == "")
	{
		QMessageBox::critical(this, "Error", "Song title cant be empty");
		return;
	}
	try {
		service.deleteTape(title);
	}
	catch (repoError re) {
		QMessageBox::critical(this, "Repo Error", re.what());
		return;
	}
	populateRepoList();
}

void GUI::saveTape()
{
	string title = this->titleLineEdit->text().toStdString();
	if (title == "")
	{
		QMessageBox::critical(this, "Error", "Song title cant be empty");
		return;
	}
	try {
		exitCode eCode = service.saveToMyList(title);
		if (eCode == 0) {
			QMessageBox::critical(this, "Repo Error", "Tape not in Repo");
			return;
		}
	}
	catch (repoError re) {
		QMessageBox::critical(this, "Repo Error", re.what());
		return;
	}
	populateMyList();
}

void GUI::filterTape()
{

	QListWidget* fiteredListWidget = new QListWidget{};
	string filmedLocation = this->filmedLocationLineEdit->text().toStdString();
	int accessCount = this->accessCountLineEdit->text().toInt();
	vector<Tape> tapesFromRepo = service.getFilteredList(filmedLocation, accessCount);
	for (Tape currentTape : tapesFromRepo) {

		fiteredListWidget->addItem(QString::fromStdString(currentTape.toString()));
	}
	QWidget* newWindow = new QWidget;
	newWindow->setWindowTitle("Filter result");
	QVBoxLayout *filterLabel = new QVBoxLayout{};
	filterLabel->addWidget(fiteredListWidget);
	//newWindow->setCentralWidget(*filterLabel);
	newWindow->setLayout(filterLabel);
	newWindow->show();
	
}

void GUI::updateTape()
{
	string title = this->titleLineEdit->text().toStdString();
	string filmedLocation = this->filmedLocationLineEdit->text().toStdString();
	date adate;
	int accessCount;
	try {
		adate = stringToDate(this->dateLineEdit->text().toStdString());
		accessCount = this->accessCountLineEdit->text().toInt();
	}
	catch (exception error) {
		QMessageBox::critical(this, "Repo Error", "Date  and access Count must be of type int-int-int  and int, respectively");
		return;
	}
	string footagePreview = this->footagePreviewLineEdit->text().toStdString();
	Tape tapeToUpdate(title, filmedLocation, adate.day, adate.month, adate.year, accessCount, footagePreview);
	try {
		service.updateTape(tapeToUpdate);
	}
	catch (repoError re) {
		QMessageBox::critical(this, "Repo Error", re.what());
		return;
	}
	catch (validatorError ve) {
		QMessageBox::critical(this, "Validator Error", ve.what());
		return;
	}
	populateRepoList();
}

void GUI::nextTape()
{
	int size = tapeListWidget->count()-1;
	if (tapeListWidget->item(size)->isSelected())
	{
		tapeListWidget->item(size)->setSelected(0);
		tapeListWidget->item(0)->setSelected(1);
		return;
	}
	for (int i = 0; i < size-1; ++i)
	{
		if (tapeListWidget->item(i)->isSelected())
		{
			tapeListWidget->item(i)->setSelected(0);
			tapeListWidget->item(i+1)->setSelected(1);
			return;
		}
	}
	tapeListWidget->item(0)->setSelected(1);
}
