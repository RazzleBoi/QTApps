#include "service.h"
#include "Repository.h"
#include <stdio.h>
#include <string.h>
#include <string>


Service::~Service()
{
	if(fieldAgentsList)
		delete fieldAgentsList;
	if(repository)
		delete[] repository;
}
void Service::configureRepo()
{
	ifstream configFile("configRepo.txt");
	string repoType,prefix;
	configFile >> prefix >> repoType;
	if (repoType == "file") {
		repository = new csvFileRepo("csvFileRepo.csv");
		return;
	}
	repository = new memoryRepo();

}
void Service::setFileNameForRepo(const string fileName)
{
	//this->repository->setFileToStoreData(fileName);
}

void Service::setMyListFileType(const string fileName)
{
	string extension = fileName.substr(fileName.find_last_of(".")+1);
	if (extension == "html") {
		fieldAgentsList = new htmlFileRepo(fileName);
	}
	else {
		fieldAgentsList = new csvFileRepo(fileName);
	}
}

std::vector<Tape> Service::getListOfAllTapes()
{
	return this->repository->getAllTapes();
}

int Service::getNumberOfTapes()
{
	return this->repository->numberOfTapes();
}

void Service::openMyList()
{/*
	string fileName = fieldAgentsList->getFileName();
	string extension = fileName.substr(fileName.find_last_of(".") + 1);
	std::wstring_convert<convert_t, wchar_t> strconverter;
	std::wstring fullPath = strconverter.from_bytes(fileName);
	LPCWSTR result = fullPath.c_str();
	ShellExecute(NULL, L"open", result, NULL, NULL, SW_SHOWNORMAL);
	*/
}


void Service::addTape(Tape tapeToBeAdded)
{
	validator.validateTape(tapeToBeAdded);
	this->repository->addTape(tapeToBeAdded);
	auto pointerAction = make_unique<addAction>(tapeToBeAdded, repository);
	this->undoStack.push_back(move(pointerAction));
}

void Service::updateTape(Tape tapeToUpdate)
{
	validator.validateTape(tapeToUpdate);
	Tape oldTape = this->repository->updateTape(tapeToUpdate);
	auto pointerAction = make_unique<updateAction>(oldTape, tapeToUpdate, repository);
	this->undoStack.push_back(move(pointerAction));

}

void Service::deleteTape(string title)
{
	Tape oldTape = this->repository->removeTape(title);
	auto pointerAction = make_unique<removeAction>(oldTape, repository);
	this->undoStack.push_back(move(pointerAction));
}

Tape Service::getTapeAtPosition(int position) {
	return this->repository->getTapeWithGivenPosition(position);
}

bool Service::saveToMyList(string title)
{
	int positionOfSearchedTitleTape = this->repository->searchTape(title);
	if (positionOfSearchedTitleTape == -1) {
		
		return 0;
	}
	Tape tapeToBeAdded = this->repository->getTapeWithGivenPosition(positionOfSearchedTitleTape);
	this->fieldAgentsList->addTape(tapeToBeAdded);
	return 1;
}

std::vector<Tape> Service::getFieldAgentsList()
{

	std::vector<Tape> deepCopyOfFieldAgentsList(this->fieldAgentsList->getAllTapes());
	return deepCopyOfFieldAgentsList;
}

std::vector<Tape> Service::getFilteredList(string Location, int maximumAccessCount)
{
	std::vector<Tape>  repoList = this->repository->getAllTapes();
	std::vector<Tape>  filteredList{};
	for (auto& currentTape : repoList)
		if (currentTape.getFilmedAt() == Location && currentTape.getAccessCount() < maximumAccessCount)
				filteredList.push_back(currentTape);
		
	return filteredList;
}

Tape Service::getNextTape()
{
	Tape currentTape = this->getTapeAtPosition(this->currentPositionInList);
	this->currentPositionInList++;
	if (this->currentPositionInList == this->getNumberOfTapes())
		this->currentPositionInList = 0;
	return currentTape;
}

void Service::undo()
{
	if (undoStack.size() == 0) {
		throw undoError("Nothing to undo!");
	}
	unique_ptr<Action> lastAction = move(undoStack.back());
	lastAction->executeUndo();
	undoStack.pop_back();
	redoStack.push_back(move(lastAction));
	
}

void Service::redo()
{
	if (redoStack.size() == 0) {
		throw undoError("Nothing to redo!");
	}
	unique_ptr<Action> lastAction = move(redoStack.back());
	lastAction->executeRedo();
	redoStack.pop_back();
	undoStack.push_back(move(lastAction));

}

void addAction::executeRedo()
{
	this->repository->addTape(tapeAdded);
}

void addAction::executeUndo()
{
	this->tapeAdded = this->repository->removeTape(this->tapeAdded.getTitle());
}

void removeAction::executeRedo()
{
	this->tapeRemoved = this->repository->removeTape(tapeRemoved.getTitle());
}

void removeAction::executeUndo()
{
	this->repository->addTape(this->tapeRemoved);
}

void updateAction::executeUndo()
{
	newTape = this->repository->updateTape(oldTape);
}
void updateAction::executeRedo()
{
	oldTape = this->repository->updateTape(newTape);
}
